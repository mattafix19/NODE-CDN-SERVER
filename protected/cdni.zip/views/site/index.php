<?php
/* @var $this SiteController */

$this->pageTitle="CDNi";
?>

<h1><i>CDNi interconnection</i></h1>

<p>This is prototype web-based application to create and manage interconnection between content delivery networks.</p>


<p>For more details on how to further develop this application, please contact us on
the e-mail richard.rostecky@gmail.com.
</p>
